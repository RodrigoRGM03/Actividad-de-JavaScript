function pedirEdad() {
    const edad = prompt("Introduce tu edad:");
    if (edad === null) {
        document.getElementById('output').innerText = "Operación cancelada.";
        return;
    }
    
    const edadNum = parseInt(edad, 10);
    
    if (isNaN(edadNum) || edadNum < 0) {
        document.getElementById('output').innerText = "Por favor, introduce una edad válida.";
    } else if (edadNum >= 18) {
        document.getElementById('output').innerText = "Eres mayor de edad, ya puedes conducir.";
    } else {
        document.getElementById('output').innerText = "Eres menor de edad, no puedes conducir.";
    }
}


function pedirNota() {
    const nota = prompt("Introduce tu nota (0-10):");

    if (nota === null) {
        document.getElementById('output').innerText = "Operación cancelada.";
        return;
    }
    
    const notaNum = parseFloat(nota);
    
    if (isNaN(notaNum) || notaNum < 0 || notaNum > 10) {
        document.getElementById('output').innerText = "Por favor, introduce una nota válida entre 0 y 10.";
    } else {
        let calificacion;
        if (notaNum >= 9) {
            calificacion = "Sobresaliente";
        } else if (notaNum >= 7) {
            calificacion = "Notable";
        } else if (notaNum >= 6) {
            calificacion = "Bien";
        } else if (notaNum >= 5) {
            calificacion = "Suficiente";
        } else {
            calificacion = "Insuficiente";
        }
        document.getElementById('output').innerText = `Tu calificación es: ${calificacion}`;
    }
}

function concatenarCadenas() {
    let cadenas = [];
    let cadena;
    while ((cadena = prompt("Introduce una cadena de texto (Cancelar para terminar):")) !== null) {
        cadenas.push(cadena);
    }
    document.getElementById('output').innerText = cadenas.join('-');
}

function calcularLetraDNI() {
    const letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'];
    let numero;
    while (true) {
        numero = prompt("Introduce tu número de DNI (0-99999999) o Cancelar para terminar:");
        if (numero === null) break;
        numero = parseInt(numero);
        if (isNaN(numero) || numero < 0 || numero > 99999999) {
            alert("Número de DNI no válido. Inténtalo de nuevo.");
        } else {
            const letra = letras[numero % 23];
            document.getElementById('output').innerText = `La letra de tu DNI es: ${letra}`;
            break;
        }
    }
}
